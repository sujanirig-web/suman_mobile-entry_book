// firebase initial
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getFirestore, collection, addDoc, doc, updateDoc, deleteDoc, onSnapshot } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";
import { getAuth, signInWithEmailAndPassword, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
const firebaseConfig = {
    apiKey: "AIzaSyDFEwq_evYAot2DEtErBO58u6ABWBjVZ5M",
    authDomain: "relife-entry-book.firebaseapp.com",
    projectId: "relife-entry-book",
    storageBucket: "relife-entry-book.firebasestorage.app",
    messagingSenderId: "736685646269",
    appId: "1:736685646269:web:387441b954cd4f123f72d4"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(); // This connects the Auth service to your app

// --- 2. LOGIN MANAGER & AUTH GATEKEEPER ---
onAuthStateChanged(auth, (user) => {
    const overlay = document.getElementById('loginOverlay');
    if (user) {
        overlay.style.display = 'none'; // Hide login
        loadData(); // Start the app data sync
    } else {
        overlay.style.display = 'flex'; // Show login
        repairs = [];
        window.filterTable();
    }
});

document.getElementById('loginBtn').onclick = async () => {
    const email = document.getElementById('loginEmail').value;
    const pass = document.getElementById('loginPass').value;
    const errorEl = document.getElementById('loginError');
    const btn = document.getElementById('loginBtn');

    try {
        btn.textContent = "Verifying...";
        await signInWithEmailAndPassword(auth, email, pass);
    } catch (err) {
        btn.textContent = "Access Dashboard";
        errorEl.textContent = "Invalid Credentials";
        errorEl.style.display = "block";
    }
};


// --- 2. EXISTING LOGIC (PRESERVED) ---
const STORAGE_KEY = 'relife_entrybook_v1';
let repairs = [];
let currentTab = 'all';
let currentImageData = null;
let currentlyEditingId = null;

// Ensure global functions are accessible to HTML onclicks
window.handleImageUpload = function(input) {
    const file = input.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            currentImageData = e.target.result;
            const preview = document.getElementById('imagePreview');
            document.getElementById('previewImg').src = currentImageData;
            preview.classList.remove('hidden');
        };
        reader.readAsDataURL(file);
    }
};

window.removeImage = function() {
    currentImageData = null;
    document.getElementById('imagePreview').classList.add('hidden');
    document.getElementById('photoGallery').value = '';
    document.getElementById('photoCamera').value = '';
};

window.viewImage = function(src) {
    const modal = document.getElementById('viewImageModal');
    document.getElementById('fullSizeImage').src = src;
    modal.classList.remove('hidden');
};

window.toggleModal = function(id) {
    const modal = document.getElementById(id);
    if (modal) {
        modal.classList.toggle('hidden');
        if (modal.classList.contains('hidden')) {
            document.getElementById('repairForm').reset();
            window.removeImage();
            currentlyEditingId = null;
            document.getElementById('modalTitle').textContent = "New Repair Job";
        }
    }
};

// --- 1. UPDATED DATA CORE (FIREBASE SYNC) ---
function loadData() {
    const repairsCol = collection(db, "repairs");
    
    // Listen for real-time updates from Firebase Cloud
    onSnapshot(repairsCol, (snapshot) => {
        // Map the cloud data to your local 'repairs' array
        repairs = snapshot.docs.map(doc => ({
            ...doc.data(),
            firebaseDocId: doc.id // This is the unique key needed for editing/deleting
        }));

        // Sort: Newest entries at the top based on the cloud timestamp
        repairs.sort((a, b) => {
            const dateA = new Date(a.createdAt || 0);
            const dateB = new Date(b.createdAt || 0);
            return dateB - dateA;
        });

        // This automatically refreshes your table whenever Firebase changes
        window.filterTable(); 
        
        // Backup to LocalStorage for offline viewing
        localStorage.setItem(STORAGE_KEY, JSON.stringify(repairs));
    });
}

function saveData() {
    // With Firebase, we mainly use this to keep the local backup updated
    localStorage.setItem(STORAGE_KEY, JSON.stringify(repairs));
}
window.editRepair = function(id) {
    const r = repairs.find(x => x.id === id);
    if (!r) return;
    currentlyEditingId = id;
    document.getElementById('modalTitle').textContent = "Edit Repair #" + id;
    document.getElementById('customerName').value = r.customer;
    document.getElementById('customerPhone').value = r.phone || '';
    document.getElementById('deviceModel').value = r.device;
    document.getElementById('snNumber').value = r.sn || '';
    document.getElementById('issueType').value = r.issue;
    document.getElementById('cost').value = r.cost;
    document.getElementById('paid').value = r.paid;
    if (r.image) {
        currentImageData = r.image;
        document.getElementById('previewImg').src = r.image;
        document.getElementById('imagePreview').classList.remove('hidden');
    }
    window.toggleModal('entryModal');
};

function renderTable(data = repairs) {
    const tbody = document.getElementById('repairTableBody');
    tbody.innerHTML = '';
    document.getElementById('noDataMessage').classList.toggle('hidden', data.length > 0);

    data.forEach(repair => {
        const due = (Number(repair.cost) || 0) - (Number(repair.paid) || 0);
        const tr = document.createElement('tr');
        tr.className = "table-row-hover group border-b border-slate-50";
        tr.innerHTML = `
            <td class="px-8 py-6">
                <div class="text-xs font-bold text-slate-400">#${repair.id}</div>
                <div class="text-[10px] font-bold text-indigo-600 uppercase mt-1">SN: ${repair.sn || 'NONE'}</div>
                <div class="text-[9px] font-bold text-slate-400 uppercase mt-1 tracking-wider">${repair.date || ''}</div>
            </td>
            <td class="px-6 py-6">
                <div class="font-bold text-slate-800 text-sm">${repair.customer}</div>
                <div class="font-bold text-green-600 text-[10px] uppercase">${repair.device}</div>
            </td>
            <td class="px-6 py-6">
                <div class="text-xs font-bold text-slate-600">${repair.issue}</div>
                ${repair.image ? `<img src="${repair.image}" onclick="viewImage('${repair.image}')" class="mt-2 w-10 h-10 rounded-lg object-cover cursor-pointer border shadow-sm">` : ''}
            </td>
            <td class="px-6 py-6">
                <button onclick="updateStatus('${repair.id}')" class="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${repair.status === 'completed' ? 'bg-emerald-50 text-emerald-600' : 'bg-orange-50 text-orange-600'}">${repair.status}</button>
            </td>
            <td class="px-6 py-6">
                <div class="text-xs font-bold ${due > 0 ? 'text-red-600' : 'text-emerald-500'}">Due: रू${due.toLocaleString()}</div>
            </td>
            <td class="px-8 py-6 text-right space-x-3">
                <button onclick="editRepair('${repair.id}')" class="text-slate-300 hover:text-indigo-600"><i class="fas fa-edit"></i></button>
                <button onclick="deleteRepair('${repair.id}')" class="text-slate-300 hover:text-red-500"><i class="fas fa-trash"></i></button>
            </td>
        `;
        tbody.appendChild(tr);
    });
    updateStats();
}
window.deleteRepair = async function(id) {
    if(confirm("Are you sure you want to delete this entry permanently from the cloud?")) {
        try {
            // 1. Find the repair to get the Firebase ID
            const repairToDelete = repairs.find(r => r.id === id);
            
            if (repairToDelete && repairToDelete.firebaseDocId) {
                showToast("Deleting from Cloud...");
                
                // 2. Delete from Firebase
                const docRef = doc(db, "repairs", repairToDelete.firebaseDocId);
                await deleteDoc(docRef);
                
                showToast("Entry Deleted Permanently");
            } else {
                // If it's an old local entry without a cloud ID
                repairs = repairs.filter(r => r.id !== id);
                saveData();
                window.filterTable();
                showToast("Local Entry Removed");
            }
        } catch (err) {
            console.error("Delete Error:", err);
            showToast("Error deleting from cloud");
        }
    }
};


window.updateStatus = function(id) {
    const flow = ['pending', 'repairing', 'completed', 'cancelled'];
    const r = repairs.find(x => x.id === id);
    if(r) {
        r.status = flow[(flow.indexOf(r.status) + 1) % flow.length];
        saveData(); window.filterTable();
    }
};

function updateStats() {
    const pendingCount = repairs.filter(r => r.status === 'pending' || r.status === 'repairing').length;
    const fixedCount = repairs.filter(r => r.status === 'completed').length;
    const revenue = repairs.reduce((a, c) => a + (Number(c.paid) || 0), 0);
    const credit = repairs.reduce((a, c) => a + Math.max(0, (Number(c.cost) || 0) - (Number(c.paid) || 0)), 0);

    document.getElementById('stat-total').textContent = repairs.length;
    document.getElementById('stat-active').textContent = pendingCount;
    document.getElementById('stat-fixed-count').textContent = fixedCount;
    document.getElementById('stat-revenue').textContent = `रू${revenue.toLocaleString()}`;
    document.getElementById('stat-credit').textContent = `रू${credit.toLocaleString()}`;
}

window.setTab = function(tab) {
    currentTab = tab;
    document.querySelectorAll('.stat-card').forEach(card => card.classList.remove('active-tab'));
    const selectedVisual = document.getElementById(`card-${tab}`);
    if (selectedVisual) selectedVisual.classList.add('active-tab');
    window.filterTable();
};

window.filterTable = function() {
    const query = document.getElementById('searchInput').value.trim();
    const filterVal = document.getElementById('statusFilter').value;
    
    let data = repairs;

    // Tab Filter
    if (currentTab === 'pending') data = data.filter(r => r.status !== 'completed');
    if (currentTab === 'fixed') data = data.filter(r => r.status === 'completed');

    // Credit Filter
    if (filterVal === 'credit') {
        data = data.filter(r => (Number(r.cost) || 0) - (Number(r.paid) || 0) > 0);
    }

    // Smart Search
    if (query && typeof Fuse !== 'undefined') {
        const options = { keys: ['customer', 'device', 'issue', 'sn', 'id'], threshold: 0.3 };
        const fuse = new Fuse(data, options);
        data = fuse.search(query).map(result => result.item);
    }

    renderTable(data);
};

function showToast(msg) {
    const toast = document.getElementById('toast');
    document.getElementById('toastMessage').textContent = msg;
    toast.classList.remove('translate-y-20', 'opacity-0');
    setTimeout(() => toast.classList.add('translate-y-20', 'opacity-0'), 3000);
}
// submit form
document.getElementById('repairForm').onsubmit = async function(e) {
    e.preventDefault();
    showToast("Syncing with Cloud...");

    let finalImageUrl = currentImageData;

    try {
        // 1. IMAGE UPLOAD (ImgBB)
        if (currentImageData && currentImageData.startsWith('data:image')) {
            const apiKey = "50e3528b32a0303dab2a1de6244e6198"; 
            const base64Data = currentImageData.split(',')[1];
            const imgFormData = new FormData();
            imgFormData.append("image", base64Data);

            const res = await fetch(`https://api.imgbb.com/1/upload?key=${apiKey}`, {
                method: "POST",
                body: imgFormData
            });
            const result = await res.json();
            if (result.success) finalImageUrl = result.data.url;
        }

        // 2. PREPARE DATA
        const formData = {
            customer: document.getElementById('customerName').value,
            phone: document.getElementById('customerPhone').value,
            device: document.getElementById('deviceModel').value,
            sn: document.getElementById('snNumber').value,
            issue: document.getElementById('issueType').value,
            cost: Number(document.getElementById('cost').value) || 0,
            paid: Number(document.getElementById('paid').value) || 0,
            image: finalImageUrl,
            updatedAt: new Date().toISOString(),
            passcode: "RE_LiFE_8090"

            
        };

        const repairsCol = collection(db, "repairs");

        if (currentlyEditingId) {
            // EDIT EXISTING
            const repairToEdit = repairs.find(r => r.id === currentlyEditingId);
            if (!repairToEdit || !repairToEdit.firebaseDocId) {
                throw new Error("Cloud ID missing. Delete and re-add this entry once.");
            }
            const docRef = doc(db, "repairs", repairToEdit.firebaseDocId);
            await updateDoc(docRef, formData);
            showToast("Cloud Updated ✅");
        } else {
            // NEW ENTRY LOGIC
            const now = new Date();
            let finalDate = "";

            // YOUR ORIGINAL NEPALI DATE LOGIC
            try {
                if (typeof NepaliDate !== 'undefined') {
                    const nDate = new window.NepaliDate(now);
                    const nepaliDate = nDate.format('YYYY/MM/DD');
                    const time = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
                    finalDate = `${nepaliDate} | ${time}`;
                } else {
                    finalDate = now.toLocaleDateString();
                }
            } catch (err) {
                finalDate = now.toLocaleDateString();
            }

            const localId = Math.floor(1000 + Math.random() * 9000).toString();
            const newEntry = {
                id: localId,
                ...formData,
                status: 'pending',
                date: finalDate,
                createdAt: now.toISOString()
            };

            // Save to Firebase
            await addDoc(repairsCol, newEntry);
            showToast("Saved to Cloud ☁️");
        }

      window.toggleModal('entryModal');
        // onSnapshot in loadData() will refresh the table automatically

    } catch (err) {
        console.error("Sync Error:", err);
        showToast("Error: " + err.message);
    }
};

// CLEANEST STARTUP LOGIC:
window.onload = () => { 
    renderTable(); // Just draws the empty table structure
    // We don't call loadData() here because the Auth Bouncer 
    // will call it automatically once the user is logged in.
};